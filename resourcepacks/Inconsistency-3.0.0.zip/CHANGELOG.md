# Changelog

## 3.0.0 - 2020-1-22
### Added
- Rail
- Curved Rail
- Activator Rail
- Powered Rail
- Detector Rail
- Lanterns
- Chain
- Lilypad
- Stonecutter
- Ladder
- Iron Bars

### Changed
- Reduced model complexity of rails
- Rails now use dedicated textures
- Iron bars item model better matches block model
- Reduced size of rails and ladder in GUI view
- Added additional cullfaces to rails and iron bars
