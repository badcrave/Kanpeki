# Changelog

## 3.0.0 - 2021-1-2
### Added
- Alternate fence item model
