# Changelog

## 3.0.0 - 2020-8-19
### Added
- [Blockus](https://www.curseforge.com/minecraft/mc-mods/blockus)
    - Beveled Glass Panes
    - Doors (Bamboo/Charred Wood/White Oak/Stone/Obsidian/Paper)
    - Paper Wall
    - Wooden Frame
- [Cinderscapes](https://www.curseforge.com/minecraft/mc-mods/cinderscapes)
    - Doors (Scorched/Umbral)
    - Signs (Scorched/Umbral)
- [Modern Glass Doors](https://www.curseforge.com/minecraft/mc-mods/modern-glass-doors)
    - Glass Doors (Iron/Oak/Spruce/Birch/Jungle/Acacia/Dark Oak)
- [Tech Reborn](https://www.curseforge.com/minecraft/mc-mods/techreborn)    
    - Cables (Copper/Tin/HV/Gold/Glass Fiber/Superconductor)
    - Insulated Cables (Copper/Tin/HV/Gold)    
    - Resin Basin
    - Rubber Door
- [Terrestria](https://www.curseforge.com/minecraft/mc-mods/terrestria)
    - Boats (Redwood/Hemlock/Rubber Wood/Cypress/Willow/Japanese Maple/Rainbow Eucalyptus/Sakura/Yucca Palm)
    - Doors (Redwood/Hemlock/Rubber Wood/Cypress/Willow/Japanese Maple/Rainbow Eucalyptus/Sakura/Yucca Palm)
    - Signs (Redwood/Hemlock/Rubber Wood/Cypress/Willow/Japanese Maple/Rainbow Eucalyptus/Sakura/Yucca Palm)
- [Traverse](https://www.curseforge.com/minecraft/mc-mods/traverse)
    - Fir Boat
    - Fir Door
    - Fir Sign
